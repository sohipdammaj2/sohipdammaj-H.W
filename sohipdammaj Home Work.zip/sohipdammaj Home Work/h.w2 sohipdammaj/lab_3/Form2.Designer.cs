﻿namespace lab_3
{
    partial class sender
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.brownform = new System.Windows.Forms.Label();
            this.yllowform = new System.Windows.Forms.Label();
            this.btnred = new System.Windows.Forms.Button();
            this.btngreen = new System.Windows.Forms.Button();
            this.btnblue = new System.Windows.Forms.Button();
            this.btncolor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labtypecolor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // brownform
            // 
            this.brownform.AutoSize = true;
            this.brownform.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.brownform.Font = new System.Drawing.Font("Tahoma", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brownform.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.brownform.Location = new System.Drawing.Point(12, 30);
            this.brownform.Name = "brownform";
            this.brownform.Size = new System.Drawing.Size(75, 24);
            this.brownform.TabIndex = 0;
            this.brownform.Text = "brown";
            this.brownform.Click += new System.EventHandler(this.brownform_Click);
            // 
            // yllowform
            // 
            this.yllowform.AutoSize = true;
            this.yllowform.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.yllowform.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yllowform.ForeColor = System.Drawing.Color.Yellow;
            this.yllowform.Location = new System.Drawing.Point(123, 30);
            this.yllowform.Name = "yllowform";
            this.yllowform.Size = new System.Drawing.Size(64, 24);
            this.yllowform.TabIndex = 1;
            this.yllowform.Text = "yllow";
            this.yllowform.Click += new System.EventHandler(this.yllowform_Click);
            // 
            // btnred
            // 
            this.btnred.ForeColor = System.Drawing.Color.Red;
            this.btnred.Location = new System.Drawing.Point(289, 107);
            this.btnred.Name = "btnred";
            this.btnred.Size = new System.Drawing.Size(75, 23);
            this.btnred.TabIndex = 4;
            this.btnred.Text = "red";
            this.btnred.UseVisualStyleBackColor = true;
            this.btnred.Click += new System.EventHandler(this.btnred_Click);
            // 
            // btngreen
            // 
            this.btngreen.ForeColor = System.Drawing.Color.Green;
            this.btngreen.Location = new System.Drawing.Point(172, 107);
            this.btngreen.Name = "btngreen";
            this.btngreen.Size = new System.Drawing.Size(75, 23);
            this.btngreen.TabIndex = 5;
            this.btngreen.Text = "green";
            this.btngreen.UseVisualStyleBackColor = true;
            this.btngreen.Click += new System.EventHandler(this.btngreen_Click);
            // 
            // btnblue
            // 
            this.btnblue.ForeColor = System.Drawing.Color.Blue;
            this.btnblue.Location = new System.Drawing.Point(42, 107);
            this.btnblue.Name = "btnblue";
            this.btnblue.Size = new System.Drawing.Size(75, 23);
            this.btnblue.TabIndex = 6;
            this.btnblue.Text = "blue";
            this.btnblue.UseVisualStyleBackColor = true;
            this.btnblue.Click += new System.EventHandler(this.btnblue_Click);
            // 
            // btncolor
            // 
            this.btncolor.AutoSize = true;
            this.btncolor.Location = new System.Drawing.Point(172, 186);
            this.btncolor.Name = "btncolor";
            this.btncolor.Size = new System.Drawing.Size(75, 27);
            this.btncolor.TabIndex = 2;
            this.btncolor.Text = "color";
            this.btncolor.UseVisualStyleBackColor = true;
            this.btncolor.Click += new System.EventHandler(this.btncolor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(192, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 7;
            this.label1.Text = "نوع الاداه المختاره";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(270, 303);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 24);
            this.label2.TabIndex = 8;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(235, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "اختر لون الصفحه";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "<<";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(89, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "<<";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(124, 243);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "<<";
            // 
            // labtypecolor
            // 
            this.labtypecolor.AutoSize = true;
            this.labtypecolor.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labtypecolor.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labtypecolor.ForeColor = System.Drawing.Color.Yellow;
            this.labtypecolor.Location = new System.Drawing.Point(12, 243);
            this.labtypecolor.Name = "labtypecolor";
            this.labtypecolor.Size = new System.Drawing.Size(55, 24);
            this.labtypecolor.TabIndex = 13;
            this.labtypecolor.Text = "type";
            // 
            // sender
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 297);
            this.Controls.Add(this.labtypecolor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnblue);
            this.Controls.Add(this.btngreen);
            this.Controls.Add(this.btnred);
            this.Controls.Add(this.btncolor);
            this.Controls.Add(this.yllowform);
            this.Controls.Add(this.brownform);
            this.Name = "sender";
            this.Text = "sender";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label brownform;
        private System.Windows.Forms.Label yllowform;
        private System.Windows.Forms.Button btnred;
        private System.Windows.Forms.Button btngreen;
        private System.Windows.Forms.Button btnblue;
        private System.Windows.Forms.Button btncolor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labtypecolor;
    }
}