﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace lab5
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        int i = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            i++;
            if (i < 9)
            {
              // pictureBox1. BackgroundImageLayout=ImageLayout.Stretch;
                pictureBox1.Image = Image.FromFile(i.ToString() + ".png");
               BackgroundImage = Image.FromFile(i.ToString() + ".png");
                BackgroundImageLayout = ImageLayout.Stretch;
            }
            else
            {
                i = 0;
            }
        }
    private void Form6_Load(object sender, EventArgs e)
        {
            BackgroundImage = Image.FromFile(@"CCNA.png");
            BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            i--;
            if (i >=1 )
            {
                //i = 9;
                pictureBox1.Image = Image.FromFile(i.ToString() + ".png");
                BackgroundImage = Image.FromFile(i.ToString() + ".png");
                BackgroundImageLayout = ImageLayout.Stretch;
            }
            else
            {
                i = 1;
            }
         
        }
    }
}
