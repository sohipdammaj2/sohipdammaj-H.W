﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Bitmap mybitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            int size = 100; // حجم المربع
           Bitmap mybitmap = new Bitmap(size, size); // إنشاء صورة جديدة بحجم 100x100

          
            for (int x = 0; x < size; x++)
            {
                int y = x; 

                // رسم الخطين العموديين
                mybitmap.SetPixel(x, y, Color.Plum); // عمود ثابت عند x = 5
                mybitmap.SetPixel(y,x, Color.Red); // صف ثابت عند y = 5

                
            }

            pictureBox1.Image = mybitmap;
        }

            private void Form4_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;// تنسيف الpictuerbox
            BackColor=Color.SkyBlue;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            int size = 100; // حجم المربع
            int bitmapSize = 200; // حجم الصورة الكاملة
            Bitmap mybitmap = new Bitmap(bitmapSize, bitmapSize); // إنشاء صورة جديدة بحجم 200x200

            // نخلي المربع بالوسط
            int startX = (bitmapSize - size) / 2;
            int startY = (bitmapSize - size) / 2;

            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    if (x == 0 || x == size - 1 || y == 0 || y == size - 1) // رسم حدود المربع
                    {
                        mybitmap.SetPixel(startX + x, startY + y, Color.Red);
                    }
                    else
                    {
                        mybitmap.SetPixel(startX + x, startY + y, Color.White); // تعبئة المربع باللون الأبيض
                    }
                }
            }

            pictureBox1.Image = mybitmap;
            BackgroundImageLayout = ImageLayout.Center;
            BackgroundImage = mybitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}