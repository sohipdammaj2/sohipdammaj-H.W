﻿using System;
using System.Threading;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            btn_move_down4.Enabled = btn_move_front3.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btn_move_front3_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i > 816; i++)
            //{
            //    button1.Left += 1;
            //}
            //for (int i = 0; i <= this.Width - button1.Width; i++)
            //{
            //    button1.Left += 1;
            //}
            //for (int i = 0; i <= this.Width / 2; i++)
            //{
            //    button1.Left += 10; // عمليه اغواء للمعالج ولاكن يتوقف الفور عن الاستجابه لاي حدث جديد
            //    for (int j = 0; j < 1000000000; j++) ;

            //}
            //for (int i = 0; i <= this.Width; i++)
            //{
            //    button1.Left += 1;
            //    System.Threading.Thread.Sleep(100);//الهاء بكل مائه هلي دزره في الثانيه
            //    Application.DoEvents();//لعمل المقاطعه والعمل على الفورم على اكثر من حدث
            //    if (button1.Left > this.Width - button1.Width)
            //    {
            //        break;
            //    }
            //}
            // من اجل عدم تهيج الفورم عند الغط علي اي مكان في الفورم عند التنفيذ نستخدم
            timer1.Start();
            threadgo = new Thread(go);
            threadgo.Start();
            
        }

        Thread threadgo;// الداله تشتغل لوحدها ولديها خيط خاص بها
        void go()
        {
            for (int i=0;i<= this.Width;i++)
            {
                Invoke((Action)(() =>{
                    // عندما يكون شغل الاداه في داخل ثريد لا تستطيع الوصول  للادوات مباشره يجب ان نصل للادوات ونحن داخل داله الانفوك

                    button1.Left += 10;
                }));
                if(button1.Left>this.Width-button1.Width-50)
                {
                    break;
                }

                System.Threading.Thread.Sleep(100);
                //Application.DoEvents();// لحدوث المقاطعه والعمل على النموذح باكثر من حدث

            }
        }

        private void btn_move_down4_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < 400; i++)
            //{
            //    button1.Top += 1;
            //}
            //for (int i = 0; i <= this.Height-button2.Height-70; i++)

            //{
            //    button2.Top += 10;
            //    System.Threading.Thread.Sleep(100);
            //    Application.DoEvents();
            //}
            for (int i = button2.Top; i <= this.Height-button2.Width-70; i++)
            {
                if(button2.Top>this.Height-button2.Width-70) 
                { 
                    break;
                }
                button2.Top += 10;
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();
                
            }
            timer1.Start();
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadgo != null)
                threadgo.Abort();
        
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        bool f = true;
        bool f1 = true;
            private void timer1_Tick(object sender, EventArgs e)
            {
                if (button1.Left + button1.Width >= this.Width)
                    f = false;

                else if (button1.Left <= 0)
                    f = true;

                if(button2.Top + button2.Height >= this.Height)
                f1 = false;
             else if (button2.Top <= 0)
                f1 = true;


            if (f)
            {
                button1.Left += 5;
               
            }
            else
            { 
                button1.Left -= 5;
                
            }
            if (f1)
            {
                button2.Top += 5;
            }
            else
            {
                button2.Top -= 5;
            }
            
           
            }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            // MessageBox.Show(this.Height.ToString());//ارتفاع الفورم
            // MessageBox.Show(button2.Top.ToString()); // المسافه المتبقيه ما فوق البوتون
           // MessageBox.Show(button2.Height.ToString());// ارتفاع البوتون نفسه 
        }

        private void btn_move_down4_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void btn_move_front3_EnabledChanged(object sender, EventArgs e)
        {
           
        }
    }
}
