﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }


        bool f = true;
        
        private void Form5_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_start_Click_1(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            // MessageBox.Show(this.Width.ToString()); // عرض الفورم
           // MessageBox.Show(btn_move.Left.ToString());// المسافه المنبقيه من يسار الفورم 
           // MessageBox.Show(btn_move.Width.ToString());// عرض الفورم نفسه 
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

            if (btn_move.Left + btn_move.Width >= this.Width)
                f = false;

            else if (btn_move.Left <= 0)
                f = true;



            if (f)
                btn_move.Left += 30;
            else

                btn_move.Left -= 30;
        }
    }
}
