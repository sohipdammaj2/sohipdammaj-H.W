﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_move_up_Click(object sender, EventArgs e)
        {
            //btnplayer.Top -= 5;
            //btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top - 5);

            if (btnplayer.Top <= 0)
            {
                MessageBox.Show("stop you cant move!");
            }
            else
            {
                btnplayer.Top -= 5;
            }
        }

        private void btn_move_down_Click(object sender, EventArgs e)
        {
            // btnplayer.Top += 5;
           
           //btnplayer.Location = new Point(btnplayer.Left, btnplayer.Top + 5);
            if (btnplayer.Top + btnplayer.Height >=  this.Height)
            {
                MessageBox.Show("you can not move");
            }
            else
            {
                btnplayer.Top += 5;
            }
        }

        private void btn_move_lift_Click(object sender, EventArgs e)
        {
            int k = 0;
            //btnplayer.Left -= 5;
            //btnplayer.Location = new Point(btnplayer.Left - 5, btnplayer.Top);

            //if(btnplayer.Location.X <= 0)
            if (btnplayer.Left <=0)
            {
                MessageBox.Show("stop ! you can not move!");
                k = Convert.ToInt32(btnplayer.Left + btnplayer.Width);
                textBox1.Text = k.ToString();
            }
            else
            {
                btnplayer.Left -= 5;
            }
        }

        private void btn_move_right_Click(object sender, EventArgs e)
        {
            // btnplayer.Left += 5;
            //btnplayer.Location = new Point(btnplayer.Left + 5, btnplayer.Top);
            if ( btnplayer.Left + btnplayer.Width >= this.Width)
            {
                MessageBox.Show("you cann't move");
            }
            else
            {
                btnplayer.Left += 5;
            }
        }

        private void btn_inc_hight_Click(object sender, EventArgs e)
        {
           // btnplayer.Height += 5;
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height + 5);
        }

        private void btn_inc_width_Click(object sender, EventArgs e)
        {
            btnplayer.Width += 5;
            //  btnplayer.Size = new Size(btnplayer.Width+5, btnplayer.Height);

        }

        private void btn_dec_width_Click(object sender, EventArgs e)
        {
           // btnplayer.Width -= 5;
            btnplayer.Size = new Size(btnplayer.Width-5, btnplayer.Height);

        }

        private void btn_dec_hight_Click(object sender, EventArgs e)
        {
            btnplayer.Height -= 5;
            btnplayer.Size = new Size(btnplayer.Width, btnplayer.Height - 5);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            this.Left = 0;
            this.Width = this.Width + 100;
            this.Height = this.Height + 100;
            //this.Size = new Size(this.Width + 100, this.Height + 100);
            //btnplayer.Top = btnplayer.Left + 20;
        }
    }
}
