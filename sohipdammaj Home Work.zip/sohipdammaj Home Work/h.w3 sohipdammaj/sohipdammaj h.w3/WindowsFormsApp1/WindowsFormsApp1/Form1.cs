﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(radioButton2.Checked.ToString());// تعيد true  radioButton2اذا كان الضغط على 
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //radioButton1.Enabled = false;// لعدم السماح بالضغط
            //radioButton1.Visible = false;// للاخفاء
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int s = 0;
            bool f = false;
          textBox1.Text = null;
            if(checkBox1.Checked) 
            {
                s += Convert.ToInt32(checkBox1.Text);
                f= true;

                // الطريقه الاولى في الكفائه افضل 
                //s += 100;
                //f = true;        
            }
            if(checkBox2.Checked) 
            {
                s += Convert.ToInt32(checkBox2.Text);
                f = true;

                //s += 200;
                //f = true;
            }
            if (checkBox3.Checked)
            {
                s += 33;
                f = true;
            }
            if (checkBox4.Checked)
            {
                s += 6;
                f = true;
            }
            if (!f)
            {
                MessageBox.Show("enter number");
            }
            else
            {
                textBox1.Text = s.ToString();
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked)
            {
                label3.ForeColor = Color.Red;
            }
            else if(radioButton2.Checked)
            {
                label3.ForeColor = Color.Yellow;
            }
            else if(radioButton3.Checked)
             {
                label3.ForeColor = Color.Green;
            }
            else if (radioButton4.Checked)
            {
                label3.ForeColor = Color.Black;
            }
            //----------------------------
            if (radioButton7.Checked)
            {
                label3.BackColor = Color.Red;
            }
            else if (radioButton8.Checked)
            {
                label3.BackColor = Color.Yellow;
            }
            else if (radioButton6.Checked)
            {
                label3.BackColor = Color.Green;
            }
            else if (radioButton5.Checked)
            {
                label3.BackColor = Color.Black;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (radioButton7.Checked) 
            //{ 
            //    label3.BackColor = Color.Red;
            //}
            //else if(radioButton8.Checked) 
            //{
            //    label3.BackColor = Color.Yellow;
            //}
            //else if (radioButton6.Checked)
            //{
            //    label3.BackColor = Color.Green;
            //}
            //else if(radioButton5.Checked)
            //{
            //    label3.BackColor = Color.Black;
            //}
        }

        private bool isPanelEnabled = false;

        private void button4_Click(object sender, EventArgs e)
        {
            // panel2.Enabled = true;// لتنفيذ مهمه واحده

            // البتن تنفذ الحالتين 
            // عكس حالة panel2
            isPanelEnabled = !isPanelEnabled; // تحديث حالة isPanelEnabled
            panel2.Enabled = isPanelEnabled; // تفعيل أو تعطيل panel2 بناءً على حالتها
        }

        private void button5_Click(object sender, EventArgs e)
        {

            panel2.Enabled=false;
        }
        bool visiblepanel = false;
        private void button6_Click(object sender, EventArgs e)
        {
            //panel2.Visible=true; // عمليه واحده على button5
            visiblepanel = !visiblepanel;
            panel2.Visible= visiblepanel;
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel2.Visible= false;
        }
    }
}
