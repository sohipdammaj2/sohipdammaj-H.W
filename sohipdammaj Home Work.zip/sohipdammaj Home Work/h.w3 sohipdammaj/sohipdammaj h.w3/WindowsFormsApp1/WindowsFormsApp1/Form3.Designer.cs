﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_move_up = new System.Windows.Forms.Button();
            this.btn_inc_hight = new System.Windows.Forms.Button();
            this.btn_dec_width = new System.Windows.Forms.Button();
            this.btn_move_lift = new System.Windows.Forms.Button();
            this.btn_dec_hight = new System.Windows.Forms.Button();
            this.btn_move_down = new System.Windows.Forms.Button();
            this.btn_inc_width = new System.Windows.Forms.Button();
            this.btn_move_right = new System.Windows.Forms.Button();
            this.btnplayer = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_move_up
            // 
            this.btn_move_up.Location = new System.Drawing.Point(269, 138);
            this.btn_move_up.Name = "btn_move_up";
            this.btn_move_up.Size = new System.Drawing.Size(75, 23);
            this.btn_move_up.TabIndex = 0;
            this.btn_move_up.Text = "^";
            this.btn_move_up.UseVisualStyleBackColor = true;
            this.btn_move_up.Click += new System.EventHandler(this.btn_move_up_Click);
            // 
            // btn_inc_hight
            // 
            this.btn_inc_hight.Location = new System.Drawing.Point(269, 182);
            this.btn_inc_hight.Name = "btn_inc_hight";
            this.btn_inc_hight.Size = new System.Drawing.Size(75, 23);
            this.btn_inc_hight.TabIndex = 1;
            this.btn_inc_hight.Text = "+";
            this.btn_inc_hight.UseVisualStyleBackColor = true;
            this.btn_inc_hight.Click += new System.EventHandler(this.btn_inc_hight_Click);
            // 
            // btn_dec_width
            // 
            this.btn_dec_width.Location = new System.Drawing.Point(194, 222);
            this.btn_dec_width.Name = "btn_dec_width";
            this.btn_dec_width.Size = new System.Drawing.Size(75, 23);
            this.btn_dec_width.TabIndex = 2;
            this.btn_dec_width.Text = "-";
            this.btn_dec_width.UseVisualStyleBackColor = true;
            this.btn_dec_width.Click += new System.EventHandler(this.btn_dec_width_Click);
            // 
            // btn_move_lift
            // 
            this.btn_move_lift.Location = new System.Drawing.Point(113, 222);
            this.btn_move_lift.Name = "btn_move_lift";
            this.btn_move_lift.Size = new System.Drawing.Size(75, 23);
            this.btn_move_lift.TabIndex = 3;
            this.btn_move_lift.Text = "<";
            this.btn_move_lift.UseVisualStyleBackColor = true;
            this.btn_move_lift.Click += new System.EventHandler(this.btn_move_lift_Click);
            // 
            // btn_dec_hight
            // 
            this.btn_dec_hight.Location = new System.Drawing.Point(269, 252);
            this.btn_dec_hight.Name = "btn_dec_hight";
            this.btn_dec_hight.Size = new System.Drawing.Size(75, 23);
            this.btn_dec_hight.TabIndex = 4;
            this.btn_dec_hight.Text = "-";
            this.btn_dec_hight.UseVisualStyleBackColor = true;
            this.btn_dec_hight.Click += new System.EventHandler(this.btn_dec_hight_Click);
            // 
            // btn_move_down
            // 
            this.btn_move_down.Location = new System.Drawing.Point(269, 302);
            this.btn_move_down.Name = "btn_move_down";
            this.btn_move_down.Size = new System.Drawing.Size(70, 23);
            this.btn_move_down.TabIndex = 5;
            this.btn_move_down.Text = "v";
            this.btn_move_down.UseVisualStyleBackColor = true;
            this.btn_move_down.Click += new System.EventHandler(this.btn_move_down_Click);
            // 
            // btn_inc_width
            // 
            this.btn_inc_width.Location = new System.Drawing.Point(345, 222);
            this.btn_inc_width.Name = "btn_inc_width";
            this.btn_inc_width.Size = new System.Drawing.Size(75, 23);
            this.btn_inc_width.TabIndex = 6;
            this.btn_inc_width.Text = "+";
            this.btn_inc_width.UseVisualStyleBackColor = true;
            this.btn_inc_width.Click += new System.EventHandler(this.btn_inc_width_Click);
            // 
            // btn_move_right
            // 
            this.btn_move_right.Location = new System.Drawing.Point(426, 222);
            this.btn_move_right.Name = "btn_move_right";
            this.btn_move_right.Size = new System.Drawing.Size(75, 23);
            this.btn_move_right.TabIndex = 7;
            this.btn_move_right.Text = ">";
            this.btn_move_right.UseVisualStyleBackColor = true;
            this.btn_move_right.Click += new System.EventHandler(this.btn_move_right_Click);
            // 
            // btnplayer
            // 
            this.btnplayer.Location = new System.Drawing.Point(60, 79);
            this.btnplayer.Name = "btnplayer";
            this.btnplayer.Size = new System.Drawing.Size(75, 34);
            this.btnplayer.TabIndex = 8;
            this.btnplayer.Text = "player";
            this.btnplayer.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(256, 355);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 24);
            this.textBox1.TabIndex = 9;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 382);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnplayer);
            this.Controls.Add(this.btn_move_right);
            this.Controls.Add(this.btn_inc_width);
            this.Controls.Add(this.btn_move_down);
            this.Controls.Add(this.btn_dec_hight);
            this.Controls.Add(this.btn_move_lift);
            this.Controls.Add(this.btn_dec_width);
            this.Controls.Add(this.btn_inc_hight);
            this.Controls.Add(this.btn_move_up);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_move_up;
        private System.Windows.Forms.Button btn_inc_hight;
        private System.Windows.Forms.Button btn_dec_width;
        private System.Windows.Forms.Button btn_move_lift;
        private System.Windows.Forms.Button btn_dec_hight;
        private System.Windows.Forms.Button btn_inc_width;
        private System.Windows.Forms.Button btn_move_right;
        private System.Windows.Forms.Button btnplayer;
        private System.Windows.Forms.Button btn_move_down;
        private System.Windows.Forms.TextBox textBox1;
    }
}